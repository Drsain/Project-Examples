import numpy as np
import pandas as pd
import matplotlib as plt
import json


train_file = 'train-v2.0.json'
dev_file = 'dev-v2.0.json'

#Loading training data (JSON) into python dictionary
#with open(train_file) as f:
	#for line in f:
		#data_dict = json.loads(line)

df = pd.read_json(train_file)
sub_1 = df.data.values
df_1 = pd.DataFrame(sub_1)




print(df_1)




#baby.py 