#ifndef GAME_H_INCLUDED
#define GAME_H_INCLUDED

#include "player.h"
#include "territory.h"
#include <string>
#include <iostream>
#include <math.h>
using namespace std;

class game{
    public:
        ///default
        game();
        ///a game with the number of users
        game(int);
        ///a game with a save file
        game(string);
        ///destructor
        ~game();

        ///the array of players
        player playerArray[5];
        ///the array of territories
        territory gameBoard[51][51];

        ///a function to save a game
        string saveGame();
        ///a function to load a game
        void loadGame(string);

        ///a function that sets the size of the board
        void setSize(int,int);
        ///a function that gets the individual sizes of the board
        int getLength();
        int getWidth();

        ///a function that ends the current turn
        void endTurn();

        ///a function that is called each turn. It takes in the name of the current player then lets the player decide what to do. It calls other functions until the turn limit has been reached, then calls the endTurn function.
        void turn(string);

        ///a function that is called during turn 5 times to figure out what the user wants to do
        void userTurn();
        ///a function that is called during turn 5 times and randomly does something for the cpu
        void cpuTurn();

        ///a function that checks the controlled array in the player class for each player to see if they have complete control of the map. If they do it returns true and the game is over
        bool isOver();

    private:
        int lengthSize,widthSize;
        bool over = false;
};

#endif // GAME_H_INCLUDED
