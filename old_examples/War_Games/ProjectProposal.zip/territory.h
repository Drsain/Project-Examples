#ifndef TERRITORY_H_INCLUDED
#define TERRITORY_H_INCLUDED

#include <string>
#include <iostream>
#include <math.h>
using namespace std;


class territory{
    public:
        ///default
        territory();
        ///constructor with the number of armies
        territory(int);
        ///destructor
        ~territory();

        ///a variable for the number of armies
        int numArmies;
        string playerControlled;

        ///a function that takes in the number of attacking armies then returns true if taken and false if failed
        bool isTaken(int);
        ///given two armies is calculates the number of armies left after attacking
        int newArmy(int);
        ///a function that adds the two numbers together
        int addArmy(int);
    private:

};

#endif // TERRITORY_H_INCLUDED
