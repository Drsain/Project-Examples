#ifndef PLAYER_H_INCLUDED
#define PLAYER_H_INCLUDED

#include "territory.h"
#include <string>
#include <iostream>
#include <math.h>
using namespace std;

class player{
    public:
        ///default
        player();
        ///constructor with the name of a file to read in player stats
        player(string);
        ///destructor
        ~player();

        ///arrays of territories controlled for a player
        territory controlled[51][51];

        ///array that hold the player's stats
        int playerStatsI[];

        ///a function that sets the player's name
        void setPlayerName(int, string);

        ///functions that read in a player's stats from a file, save a player's stats to a file and then shows the players stats to the consul.
        void savePlayerStats();
        void getPlayerStats(string);
        void showPlayerStats();
    private:
        ///the player name
        string playerName;


};

#endif // PLAYER_H_INCLUDED
